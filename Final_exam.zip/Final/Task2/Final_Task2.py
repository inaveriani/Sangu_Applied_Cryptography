import os
import rsa  # For RSA key generation and encryption/decryption
from Cryptodome.Cipher import AES  # For AES encryption/decryption
from Cryptodome.Util.Padding import pad, unpad  # For padding data for AES
import hashlib  # For SHA-256 hashing
import secrets  # For generating cryptographically secure random numbers
import time

# Define the output directory
output_dir = "/home/trpaslik/Desktop/Sangu/final/"

def generate_rsa_keys():
    (public_key, private_key) = rsa.newkeys(2048)  # Generate a 2048-bit RSA key
    return public_key, private_key

def write_rsa_keys_to_files(public_key, private_key, public_key_file="public.pem", private_key_file="private.pem"):
    with open(os.path.join(output_dir, public_key_file), 'wb') as f:
        f.write(public_key.save_pkcs1())  # Save public key in PKCS#1 format
    with open(os.path.join(output_dir, private_key_file), 'wb') as f:
        f.write(private_key.save_pkcs1())  # Save private key in PKCS#1 format

def generate_aes_key_and_iv():
    key = secrets.token_bytes(32)  # Generate 256-bit (32-byte) AES key
    iv = secrets.token_bytes(16)  # Generate 128-bit (16-byte) IV for AES
    return key, iv

def encrypt_file_aes(input_file, output_file, key, iv):
    cipher = AES.new(key, AES.MODE_CBC, iv)  # Create AES cipher object in CBC mode
    with open(input_file, 'rb') as infile:
        plaintext = infile.read()  # Read the plaintext from the input file
        padded_plaintext = pad(plaintext, AES.block_size)  # Pad the plaintext to a multiple of the block size
        ciphertext = cipher.encrypt(padded_plaintext)  # Encrypt the padded plaintext
        with open(os.path.join(output_dir, output_file), 'wb') as outfile:
            outfile.write(ciphertext)  # Write the ciphertext to the output file

def decrypt_file_aes(input_file, output_file, key, iv):
    cipher = AES.new(key, AES.MODE_CBC, iv)  # Create AES cipher object in CBC mode
    with open(os.path.join(output_dir, input_file), 'rb') as infile:
        ciphertext = infile.read()  # Read the ciphertext from the input file
        padded_plaintext = cipher.decrypt(ciphertext)  # Decrypt the ciphertext
        plaintext = unpad(padded_plaintext, AES.block_size)  # Unpad the plaintext
        with open(os.path.join(output_dir, output_file), 'wb') as outfile:
            outfile.write(plaintext)  # Write the plaintext to the output file

def encrypt_aes_key_rsa(aes_key, public_key, output_file="aes_key_encrypted.bin"):
    encrypted_aes_key = rsa.encrypt(aes_key, public_key)  # Encrypt the AES key with the RSA public key
    with open(os.path.join(output_dir, output_file), 'wb') as f:
        f.write(encrypted_aes_key)  # Write the encrypted AES key to a file

def decrypt_aes_key_rsa(encrypted_aes_key_file, private_key):
    with open(os.path.join(output_dir, encrypted_aes_key_file), 'rb') as f:
        encrypted_aes_key = f.read()
    decrypted_aes_key = rsa.decrypt(encrypted_aes_key, private_key)  # Decrypt the AES key
    return decrypted_aes_key

def calculate_sha256_hash(file_path):
    hasher = hashlib.sha256()  # Create a SHA-256 hash object
    with open(os.path.join(output_dir, file_path), 'rb') as file:
        while True:
            chunk = file.read(4096)  # Read the file in chunks to handle large files
            if not chunk:
                break
            hasher.update(chunk)  # Update the hash object with each chunk
    return hasher.hexdigest()  # Return the hexadecimal representation of the hash

def compare_hashes(original_hash, new_hash):
    return original_hash == new_hash

if __name__ == "__main__":
    # Create the output directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)

    # Create a dummy input file
    input_file = "alice_message.txt"
    message = "This is a secret message from Alice to Bob."
    with open(os.path.join(output_dir, input_file), "w") as f:
        f.write(message)

    # 1. Generate RSA keys for Bob
    print("Generating RSA keys for Bob...")
    rsa_start_time = time.time()
    public_key, private_key = generate_rsa_keys()
    write_rsa_keys_to_files(public_key, private_key)
    rsa_end_time = time.time()
    rsa_key_time = rsa_end_time - rsa_start_time
    print(f"RSA key pair generated in {rsa_key_time:.4f} seconds.")

    # 2. Alice creates a plaintext message in alice_message.txt (Done above)

    # 3. Alice generates a random AES-256 key and IV
    print("Generating AES key and IV...")
    aes_key, iv = generate_aes_key_and_iv()

    # 4. Encrypt the file using AES-256
    print("Encrypting the file using AES-256...")
    aes_start_time = time.time()
    encrypted_file = "encrypted_file.bin"
    encrypt_file_aes(input_file, encrypted_file, aes_key, iv)
    aes_end_time = time.time()
    aes_time = aes_end_time - aes_start_time
    print(f"File encrypted with AES in {aes_time:.4f} seconds.")

    # 5. Encrypt the AES key using Bob’s RSA public key
    print("Encrypting AES key with RSA public key...")
    encrypt_aes_key_rsa(aes_key, public_key)

    # 6. Bob decrypts the AES key using his RSA private key
    print("Decrypting AES key with RSA private key...")
    decrypted_aes_key = decrypt_aes_key_rsa("aes_key_encrypted.bin", private_key)

    # 7. Bob decrypts the file and recovers the original message
    print("Decrypting the file using AES key and IV...")
    decrypted_file = "decrypted_message.txt"
    decrypt_file_aes(encrypted_file, decrypted_file, decrypted_aes_key, iv)

    # 8. Integrity verification: Compute and compare SHA-256 hashes
    print("Verifying file integrity with SHA-256...")
    hash_start_time = time.time()
    original_hash = calculate_sha256_hash(input_file)
    new_hash = calculate_sha256_hash(decrypted_file)
    hash_end_time = time.time()
    hash_time = hash_end_time - hash_start_time
    print(f"SHA-256 hash calculated in {hash_time:.4f} seconds.")

    if compare_hashes(original_hash, new_hash):
        print("Integrity check passed: The file has not been tampered with.")
    else:
        print("Integrity check failed: The file may have been tampered with.")
    total_time = aes_time + rsa_key_time + hash_time
   
    print("All operations completed.  Check the following files in", output_dir)
    print("- alice_message.txt: Original plaintext file")
    print("- encrypted_file.bin: File encrypted with AES-256")
    print("- aes_key_encrypted.bin: AES key encrypted with RSA public key")
    print("- decrypted_message.txt: File decrypted with AES-256")
    print("- public.pem, private.pem: RSA public and private keys")
    print("- README.md: Explanation of the encryption/decryption flow and comparison between AES and RSA")