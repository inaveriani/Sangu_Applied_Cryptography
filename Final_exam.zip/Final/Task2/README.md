
# Hybrid Encryption Protocol Demonstration: AES-256 and RSA

## Objective
Demonstrate a hybrid encryption protocol using AES-256 for data encryption and RSA for key exchange.

## Scenario
Alice wants to send a secret message to Bob securely. This is achieved by combining the efficiency of AES for bulk data encryption with the key management capabilities of RSA.

## Steps
1.  **RSA Key Pair Generation:**
    * Bob generates an RSA key pair (public and private keys).
    * The public key is used to encrypt the AES key, and the private key is used to decrypt the AES key.
    * The keys are saved in `public.pem` and `private.pem` files.

2.  **Message Creation:**
    * Alice creates a plaintext message in a file named `alice_message.txt`.

3.  **AES Key and IV Generation:**
    * Alice generates a random AES-256 key and an initialization vector (IV).
    * AES is a symmetric encryption algorithm, which is very fast, and suitable for encrypting large amounts of data.

4.  **File Encryption (AES):**
    * Alice encrypts the `alice_message.txt` file using AES-256 with the generated key and IV.
    * The output is stored in `encrypted_file.bin`.

5.  **AES Key Encryption (RSA):**
    * Alice encrypts the AES key using Bob's RSA public key.
    * RSA, an asymmetric algorithm, is slower than AES but provides secure key exchange.
    * The encrypted AES key is saved in `aes_key_encrypted.bin`.

6.  **AES Key Decryption (RSA):**
    * Bob decrypts the AES key using his RSA private key.

7.  **File Decryption (AES):**
    * Bob decrypts the `encrypted_file.bin` using the decrypted AES key and the original IV to recover the original message.
    * The decrypted message is saved in `decrypted_message.txt`.

8.  **Integrity Verification (SHA-256):**
    * Bob computes the SHA-256 hash of the decrypted file (`decrypted_message.txt`).
    * The hash is compared with the SHA-256 hash of the original file (`alice_message.txt`) to ensure integrity.
    * If the hashes match, the file has not been tampered with.

## Deliverables
* `alice_message.txt`: Original plaintext file.
* `encrypted_file.bin`: File encrypted with AES-256.
* `aes_key_encrypted.bin`: AES key encrypted with Bob’s RSA public key.
* `decrypted_message.txt`: Final output decrypted by Bob.
* `public.pem`, `private.pem`: Bob’s RSA public and private keys.
* `README.md`: Explanation of the encryption/decryption flow and comparison between AES and RSA.

## Comparison between AES and RSA

### Speed
* **AES:** Significantly faster than RSA.  It is a symmetric algorithm, meaning the same key is used for encryption and decryption, which makes it very efficient for encrypting large amounts of data.
* **RSA:** Slower than AES.  It is an asymmetric algorithm, which involves more complex mathematical operations.

### Use Case
* **AES:** Used for encrypting large volumes of data, such as files and communications.  It's the workhorse of modern encryption due to its speed.
* **RSA:** Used for key exchange and digital signatures.  It's ideal for scenarios where secure transmission of a small amount of data (like encryption keys) is needed.

### Security
* **AES:** Considered very secure.  AES-256 (with a 256-bit key) is currently unbreakable with known technology.  The security of AES relies on the secrecy of the key.
* **RSA:** Also very secure, but its security relies on the difficulty of factoring large numbers.  Modern RSA keys are typically 2048 bits or larger to provide sufficient security.  It's more complex to use but provides the benefit of not needing to share a secret key for encrypting the message itself.

### Hybrid Approach
The hybrid approach combines the strengths of both AES and RSA:
* AES provides fast encryption for the bulk of the data.
* RSA provides a secure way to exchange the AES key.

This approach is more efficient and secure than using either algorithm alone.  AES handles the data, and RSA handles the key.

## Timings (Seconds)
* AES Encryption/Decryption: {aes_time:.4f}
* RSA Key Encryption/Decryption: {rsa_time:.4f}
* SHA256 Hash Calculation: {hash_time:.4f}
* Total Execution Time: {total_time:.4f}
    