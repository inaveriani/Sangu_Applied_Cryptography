from Cryptodome.PublicKey import RSA
from Cryptodome.Cipher import AES, PKCS1_OAEP
from Cryptodome.Random import get_random_bytes
import os

OUTPUT_DIR = "/home/trpaslik/Desktop/Sangu/final/"

def create_filepath(filename):
    return os.path.join(OUTPUT_DIR, filename)

# --- User A: Key Generation and Sharing ---
def generate_rsa_keys():
    os.makedirs(OUTPUT_DIR, exist_ok=True)  # Ensure the directory exists
    private_key_path = create_filepath("user_a_private.pem")
    public_key_path = create_filepath("user_a_public.pem")
    key = RSA.generate(2048)
    private_key = key.export_key()
    public_key = key.publickey().export_key()
    with open(private_key_path, "wb") as f:
        f.write(private_key)
    with open(public_key_path, "wb") as f:
        f.write(public_key)
    print(f"User A: RSA keys generated ({private_key_path}, {public_key_path})")
    return public_key

# --- User B: Encryption ---
def encrypt_message(recipient_public_key_pem, message_file="message.txt", encrypted_message_file="encrypted_message.bin", aes_key_encrypted_file="aes_key_encrypted.bin"):
    # Ensure the output directory exists
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    message_path = os.path.join(os.getcwd(), message_file) # Assuming message.txt is in the current directory
    with open(message_path, "r") as f:
        message = f.read().encode('utf-8')

    # Generate a random AES key
    aes_key = get_random_bytes(32)  # 256 bits

    # Initialize AES cipher in GCM mode (Galois/Counter Mode) for authenticated encryption
    cipher_aes = AES.new(aes_key, AES.MODE_GCM)
    ciphertext, tag = cipher_aes.encrypt_and_digest(message)
    nonce = cipher_aes.nonce

    # Encrypt the AES key using RSA public key
    recipient_public_key = RSA.import_key(recipient_public_key_pem)
    cipher_rsa = PKCS1_OAEP.new(recipient_public_key)
    encrypted_aes_key = cipher_rsa.encrypt(aes_key)

    # Save the encrypted message, nonce, and tag
    encrypted_message_path = create_filepath(encrypted_message_file)
    with open(encrypted_message_path, "wb") as f:
        f.write(nonce)
        f.write(tag)
        f.write(ciphertext)

    # Save the encrypted AES key
    aes_key_encrypted_path = create_filepath(aes_key_encrypted_file)
    with open(aes_key_encrypted_path, "wb") as f:
        f.write(encrypted_aes_key)

    print(f"User B: Message encrypted ({encrypted_message_path})")
    print(f"User B: AES key encrypted ({aes_key_encrypted_path})")

# --- User A: Decryption ---
def decrypt_message(encrypted_message_file="encrypted_message.bin", aes_key_encrypted_file="aes_key_encrypted.bin", decrypted_message_file="decrypted_message.txt", private_key_file="user_a_private.pem"):
    # Load the private key
    private_key_path = create_filepath(private_key_file)
    with open(private_key_path, "rb") as f:
        private_key = RSA.import_key(f.read())
    cipher_rsa = PKCS1_OAEP.new(private_key)

    # Load the encrypted AES key
    aes_key_encrypted_path = create_filepath(aes_key_encrypted_file)
    with open(aes_key_encrypted_path, "rb") as f:
        encrypted_aes_key = f.read()

    # Decrypt the AES key
    decrypted_aes_key = cipher_rsa.decrypt(encrypted_aes_key)

    # Load the encrypted message, nonce, and tag
    encrypted_message_path = create_filepath(encrypted_message_file)
    with open(encrypted_message_path, "rb") as f:
        nonce = f.read(16)  # Assuming 16-byte nonce for GCM
        tag = f.read(16)    # Assuming 16-byte tag for GCM
        ciphertext = f.read()

    # Initialize AES cipher for decryption
    cipher_aes = AES.new(decrypted_aes_key, AES.MODE_GCM, nonce=nonce)

    # Decrypt the message
    decrypted_message = cipher_aes.decrypt_and_verify(ciphertext, tag)

    # Save the decrypted message
    decrypted_message_path = create_filepath(decrypted_message_file)
    with open(decrypted_message_path, "wb") as f:
        f.write(decrypted_message)

    print(f"User A: AES key decrypted.")
    print(f"User A: Message decrypted ({decrypted_message_path})")

if __name__ == "__main__":
    # Create a sample message in the current directory
    with open("message.txt", "w") as f:
        f.write("This is a secret message from User B to User A.")

    # User A generates RSA keys and shares the public key
    user_a_public_key = generate_rsa_keys()

    # User B encrypts the message
    encrypt_message(user_a_public_key)

    # User A decrypts the message
    decrypt_message()

    print("\nFiles generated in {}:".format(OUTPUT_DIR))
    print(" - user_a_private.pem")
    print(" - user_a_public.pem")
    print(" - encrypted_message.bin")
    print(" - aes_key_encrypted.bin")
    print(" - decrypted_message.txt")