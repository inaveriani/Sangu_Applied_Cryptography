import hashlib
import json

def compute_hashes(filepath):
    """Computes SHA-256, SHA-1, and MD5 hashes of a file."""
    hashes = {
        "sha256": "",
        "sha1": "",
        "md5": ""
    }
    try:
        with open(filepath, 'rb') as file:
            content = file.read()
            hashes['sha256'] = hashlib.sha256(content).hexdigest()
            hashes['sha1'] = hashlib.sha1(content).hexdigest()
            hashes['md5'] = hashlib.md5(content).hexdigest()
    except FileNotFoundError:
        print(f"Error: File not found at {filepath}")
        return None
    return hashes

def store_hashes(hashes, json_filepath):
    """Stores the computed hashes in a JSON file."""
    try:
        with open(json_filepath, 'w') as json_file:
            json.dump(hashes, json_file, indent=4)
        print(f"Hashes stored in {json_filepath}")
    except Exception as e:
        print(f"Error storing hashes: {e}")

def load_hashes(json_filepath):
    """Loads hashes from a JSON file."""
    try:
        with open(json_filepath, 'r') as json_file:
            loaded_hashes = json.load(json_file)
        return loaded_hashes
    except FileNotFoundError:
        print(f"Warning: Hash file not found at {json_filepath}")
        return None
    except json.JSONDecodeError:
        print(f"Warning: Invalid JSON format in {json_filepath}")
        return None
    except Exception as e:
        print(f"Error loading hashes: {e}")
        return None

def verify_integrity(filepath, json_filepath):
    """Computes current hashes and compares them with stored hashes."""
    current_hashes = compute_hashes(filepath)
    stored_hashes = load_hashes(json_filepath)

    if current_hashes and stored_hashes:
        if current_hashes == stored_hashes:
            print("Integrity Check: PASS")
            return True
        else:
            print("Integrity Check: FAIL - File has been tampered with!")
            print("Original Hashes:", stored_hashes)
            print("Current Hashes:", current_hashes)
            return False
    else:
        print("Integrity check could not be performed.")
        return False

if __name__ == "__main__":
    original_file = "original.txt"
    tampered_file = "tampered.txt"
    hashes_file = "hashes.json"

    # 1. Compute and store hashes of the original file
    print(f"Computing and storing hashes for {original_file}...")
    original_hashes = compute_hashes(original_file)
    if original_hashes:
        store_hashes(original_hashes, hashes_file)

    print("\n--- Simulating Tampering ---\n")

    # 2. Simulate tampering (we'll modify the 'tampered.txt' which is a copy of the original)
    # The user needs to manually create 'tampered.txt' by copying 'original.txt' and modifying it.
    print(f"Verifying integrity of the original file: {original_file}")
    verify_integrity(original_file, hashes_file)

    print(f"\nVerifying integrity of the tampered file: {tampered_file}")
    verify_integrity(tampered_file, hashes_file)